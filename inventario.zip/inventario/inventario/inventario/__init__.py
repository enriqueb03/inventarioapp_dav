# __init__.py del proyecto principal - sin importaciones directas

